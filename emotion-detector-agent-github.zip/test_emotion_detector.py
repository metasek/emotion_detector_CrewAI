import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from emotion_detector import detect_emotion

test_inputs = [
    "I feel so tired today.",
    "I'm panicking about this test.",
    "Nothing really matters.",
    "I'm doing okay.",
    "Nobody wants to be around me.",
    "I'm just angry all the time.",
    "I feel low and unmotivated."
]

print("🧠 Emotion Detection Results:\n")
for msg in test_inputs:
    print(f"Input: {msg}\n→ Detected Emotion: {detect_emotion(msg)}\n")
